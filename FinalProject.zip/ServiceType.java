// first interface for selecting service type
public interface ServiceType {
// method to be able to select service type (hourly or all-day)
void selectService();
}