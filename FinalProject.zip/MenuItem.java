// parent class
public class MenuItem {
String name;

// first constructor 
public MenuItem (String name) {
this.name = name;
   }
}