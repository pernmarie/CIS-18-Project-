// second interface for appointments 
public interface Appointment {
// method to be able to schedule an appointment
void ScheduleAppointment();
}