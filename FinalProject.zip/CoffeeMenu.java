// child class 
public class CoffeeMenu extends MenuItem{

// second constructor 
public CoffeeMenu (String name) {
super(name);
}

//method 
public void showMenu(){
System.out.println ("Menu Item Selected: " + name);
   }
}
